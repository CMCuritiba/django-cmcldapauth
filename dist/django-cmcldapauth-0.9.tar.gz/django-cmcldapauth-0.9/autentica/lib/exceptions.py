class BusinessLogicException(Exception):
    pass